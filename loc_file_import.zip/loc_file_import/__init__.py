import bpy

from .graph import Graph
from .objmodel import ObjModel
from .locmodel import LocModel

def read_some_data(context, filepath, use_some_setting):
    print("running read_some_data...")

    loc = LocModel()
    loc.read(filepath)
    loc.reconstruct_triangles()
    # print(loc.T)
    obj = ObjModel()
    obj.P = loc.P
    obj.T = loc.T
    meshName = filepath.split("/")[-1].split(".")[0]
    print(meshName)
    me = bpy.data.meshes.new(meshName)
    ob = bpy.data.objects.new(meshName, me)
    me.from_pydata(obj.P, [], obj.T)
    bpy.context.scene.collection.objects.link(ob)
    # would normally load the data here
    # print(obj.P)
    # print(obj.T)
    # scn = bpy.context.scene
    #
    # # присоединяем созданный ранее объект к сцене
    #
    #
    # # делаем объект активным и выделенным
    # scn.objects = ob
    # ob.select = True
    return {'FINISHED'}


# ImportHelper is a helper class, defines filename and
# invoke() function which calls the file selector.
from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty, BoolProperty, EnumProperty
from bpy.types import Operator


class ImportSomeData(Operator, ImportHelper):
    """This appears in the tooltip of the operator and in the generated docs"""
    bl_idname = "import_loc.some_data"  # important since its how bpy.ops.import_test.some_data is constructed
    bl_label = "Import loc *.loc"
    bl_info = "loc models import"

    # ImportHelper mix-in class uses this.
    filename_ext = ".loc"

    filter_glob: StringProperty(
        default="*.loc",
        options={'HIDDEN'},
        maxlen=255,  # Max internal buffer length, longer would be clamped.
    )

    # List of operator properties, the attributes will be assigned
    # to the class instance from the operator settings before calling.
    use_setting: BoolProperty(
        name="Example Boolean",
        description="Example Tooltip",
        default=True,
    )

    type: EnumProperty(
        name="Example Enum",
        description="Choose between two items",
        items=(
            ('OPT_A', "First Option", "Description one"),
            ('OPT_B', "Second Option", "Description two"),
        ),
        default='OPT_A',
    )

    def execute(self, context):
        return read_some_data(context, self.filepath, self.use_setting)


# Only needed if you want to add into a dynamic menu.
def menu_func_import(self, context):
    self.layout.operator(ImportSomeData.bl_idname, text="Loc Data Import")


# Register and add to the "file selector" menu (required to use F3 search "Text Import Operator" for quick access).
def register():
    bpy.utils.register_class(ImportSomeData)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)


def unregister():
    bpy.utils.unregister_class(ImportSomeData)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)


if __name__ == "__main__":
    register()

    # test call
    bpy.ops.import_loc.some_data('INVOKE_DEFAULT')
