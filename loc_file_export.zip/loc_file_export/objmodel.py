import numpy as np
from .graph import Graph

class ObjModel:

    def __init__(self):
        self.P = []
        self.T = []
    def read(self,fname):

        f = open(fname)


        for line in f.readlines():
            if line[:2] == "v ":
                data = line.split()
                x = float(data[1])
                y = float(data[2])
                z = float(data[3])
                p = np.array([x,y,z])
                self.P.append(p)
            elif line[:2] == "f ":
                data = line.split()
                n1 = int(data[1].split("/")[0]) - 1
                n2 = int(data[2].split("/")[0]) - 1
                n3 = int(data[3].split("/")[0]) - 1

                self.T.append([n1,n2,n3])
        self.P = np.array(self.P)
        f.close()

    def write(self,fname):

        f = open(fname,"w")

        for p in self.P:
            line = f"v {p[0]} {p[1]} {p[2]}\n"
            f.write(line)
        f.write("\n\n")

        for tr in self.T:
            line = f"f {tr[0] + 1} {tr[1] + 1} {tr[2] + 1}\n"
            f.write(line)

        f.close()

    def create_graph(self):
        V = [i for i in range(len(self.T))]
        E = []
        S = {}

        for k,tr in enumerate(self.T):
            tr.sort()
            e1 = (tr[0],tr[1])
            e2 = (tr[1], tr[2])
            e3 = (tr[0], tr[2])
            if e1 in S:
                S[e1].append(k)
            else:
                S[e1] = [k]

            if e2 in S:
                S[e2].append(k)
            else:
                S[e2] = [k]

            if e3 in S:
                S[e3].append(k)
            else:
                S[e3] = [k]
        for e in S:
            if len(S[e]) == 2:
                E.append(S[e])

        gr = Graph(V,E)
        return gr




