from .objmodel import ObjModel
import pickle
class LocModel:

    def __init__(self):
        self.P = []
        self.T = []
        self.sequences = []
    def from_arrays(self,P,T):
        self.P = P
        self.T = T

    def make_sequences(self):
        obj = ObjModel()
        obj.P = self.P
        obj.T = self.T
        gr = obj.create_graph()
        chains = gr.make_chains()

        for chain in chains:
            # print(f"chain = {chain}")
            seq = []
            if len(chain) == 1:
                seq += self.T[chain[0]]
                self.sequences.append(seq)
                # print(f"seq: {seq}")
                # print(self.sequences)
                continue

            T1 = set(self.T[chain[0]])
            T2 = set(self.T[chain[1]])
            m = list(T1&T2)
            m.append(list(T1 - (T1&T2))[0])
            m = [m[2],m[0],m[1]]
            seq += m

            # print(m)
            T = set(m)
            # print(seq)
            for i,k in enumerate(chain[1:]):
                Tk = set(self.T[k])
                l = (Tk - (Tk&T)).pop()
                if Tk == {l,m[-1],m[-2]}:
                    seq.append(l)
                    m = [m[-2],m[-1],l]
                if Tk == {l,m[-1],m[-3]}:
                    seq.append(-l)
                    m = [m[-3], m[-1], l]

                T = set(Tk)
            self.sequences.append(seq)
            # print(f"seq: {seq}")
            # print(self.sequences)



    def write(self,fname):
        f = open(fname,"wb")

        data = {"P":self.P,"S":self.sequences}

        pickle.dump(data,f)

        f.close()
    def write_text(self,fname):

        f = open(fname,"w")

        for v in self.P:
            line = f"{v[0]} {v[1]} {v[2]}\n"
            f.write(line)
        f.write("\n")
        for seq in self.sequences:
            line = ""
            for num in seq:
                line += f"{num} "
            f.write(line + "\n")
        f.close()
    def read(self,fname):
        f= open(fname,"rb")

        data = pickle.load(f)
        f.close()
        self.P = data["P"]
        self.sequences = data["S"]

    def reconstruct_triangles(self):
        T = []
        for seq in self.sequences:
            # print(f"seq = {seq}")
            tr = [seq[0],seq[1],seq[2]]
            T.append(tr)
            if len(seq) == 3:
                continue
            for l in seq[3:]:
                if l > 0:
                    tr = [tr[1],tr[2],l]
                    T.append(tr)
                else:
                    tr = [tr[0],tr[2],-l]
                    T.append(tr)
        self.T = T

